package com.geek.text.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.geek.text.entity.Book;
import com.geek.text.entity.Rating;

/**
 * 
 * This is a Spring Data MongoDB repository interface for performing CRUD operations on the Book collection in the MongoDB database.
 *
 * @Repository annotation is used to indicate that the interface is a repository and provides the mechanism for storing, updating, 
 * and extracting data from the database.
 *
 * The JpaRepository interface is extended to inherit some of the basic CRUD methods like findById(), findAll(), save(), delete(), 
 * etc. by default.
 *
 * The first parameter of the MongoRepository interface is the type of the entity and the second parameter is the type of the 
 * identifier of the entity. In this case, the entity is Rating and its identifier type is Integer.
 *
 */

@Repository
public interface RatingRepository extends JpaRepository<Rating, Integer> {
    List<Rating> findByBook(Book book);
}