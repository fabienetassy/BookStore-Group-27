package com.geek.text.exception;

import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;

/**
 * 
 * The code above is a custom exception that extends the RuntimeException class, which will be thrown when a requested resource 
 * is not found. The annotation @ResponseStatus is used to set the HTTP response status code to HttpStatus.NOT_FOUND (i.e. 404) 
 * when this exception is thrown. The serialVersionUID field is used for serialization purposes. The constructor takes a string 
 * message that will be used to create the exception.
 *
 */

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFoundException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = -6530058477284434166L;

	public ResourceNotFoundException(String message) {
        super(message);
    }
}
