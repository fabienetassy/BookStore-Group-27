package com.geek.text.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.geek.text.entity.Book;

/**
 * 
 * This is a Spring Data MongoDB repository interface for performing CRUD operations on the Book collection in the MongoDB database.
 *
 * @Repository annotation is used to indicate that the interface is a repository and provides the mechanism for storing, updating, 
 * and extracting data from the database.
 *
 * The JpaRepository interface is extended to inherit some of the basic CRUD methods like findById(), findAll(), save(), delete(), 
 * etc. by default.
 *
 * The first parameter of the MongoRepository interface is the type of the entity and the second parameter is the type of the 
 * identifier of the entity. In this case, the entity is Book and its identifier type is Integer.
 *
 */

@Repository
public interface BookRepository extends JpaRepository<Book, Integer>{

}
