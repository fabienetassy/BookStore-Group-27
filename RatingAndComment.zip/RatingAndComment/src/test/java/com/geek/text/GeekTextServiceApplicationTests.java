package com.geek.text;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeekTextServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
